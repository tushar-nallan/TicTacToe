package com.tramsun.tictactoe.interfaces;

/**
 * Created by Tushar on 19-03-2015.
 */
public interface GameRestartable {
    public void onGameRestart();
}
