package com.tramsun.tictactoe;

/**
 * Created by Tushar on 19-03-2015.
 */
public class Constants {
    public static final String GRID_SIZE = "GRID_SIZE";
    public static final int DEFAULT_GRID_SIZE = 3;
    public static final int DEFAULT_MAX_PLAYERS = 2;
    public static final java.lang.String MAX_PLAYERS_KEY = "MAX_PLAYERS_KEY";
}
