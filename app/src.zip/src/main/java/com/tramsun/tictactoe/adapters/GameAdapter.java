package com.tramsun.tictactoe.adapters;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import com.tramsun.tictactoe.R;
import com.tramsun.tictactoe.controllers.GameData;

/**
 * Created by Tushar on 19-03-2015.
 */
public class GameAdapter extends BaseAdapter {
    private Context context;
    private GameData gameData;


    public GameAdapter(Context context, GameData gameData) {
        this.gameData = gameData;
        this.context = context;
    }

    @Override
    public int getCount() {
        return gameData.getGridLength()*gameData.getGridLength();
    }

    @Override
    public Integer getItem(int position) {
        return gameData.getGrid().get(position);
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).hashCode();
    }

    String mapping = "XOPQ";
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Integer data = getItem(position);
        TextView tv;
        if(convertView == null) {
            tv = new TextView(context);
            if(tv.getLayoutParams() == null) {
                GridView.LayoutParams lp = new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                tv.setLayoutParams(lp);
            }
            tv.setGravity(Gravity.CENTER);
            tv.setBackgroundResource(R.drawable.border);
        } else {
            tv = (TextView) convertView;
        }
        String s = data == -1? "" : mapping.charAt(data)+"";
        tv.setText(s);
        return tv;
    }
}
